Try the App: https://sidharathbansal.github.io/Weather-App/

![](images/React-App.png)

![](images/React-App-2.png)
